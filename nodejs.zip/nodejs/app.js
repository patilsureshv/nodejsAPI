const express = require("express");
const req = require("express/lib/request");
const app= express();
const mongoose = require('mongoose');
const bodyparser= require('body-parser');
const cors= require('cors');
require('dotenv/config');

//middleware
app.use(cors());

//imports routes
const postsRoute = require('./routes/posts');

app.use(bodyparser.json());

app.use('/post',postsRoute);

app.get('/',(req,res) =>{
    res.send('we are on home');
});


//connect to DB
mongoose.connect(process.env.DB_CONNECTION, () => 
    console.log('Connected to db'));

//listening server
app.listen(3000);